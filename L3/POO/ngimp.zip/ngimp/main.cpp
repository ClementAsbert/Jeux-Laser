#include"ngimp.h"

int main()
{
    ngimp ng{};
    ng.run();
    return 0;
}
