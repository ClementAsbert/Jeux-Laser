#include "rapport.h"
#include <iostream>
#include "employe.h"

rapport::~rapport()
{}
