#include "Mur.h"

Mur::Mur(int x,int y)
{}
