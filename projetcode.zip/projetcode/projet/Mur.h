#ifndef MUR_H_INCLUDED
#define MUR_H_INCLUDED

#include "Case.h"

class Mur : public Case{
public:
    Mur(int x,int y);
};

#endif // MUR_H_INCLUDED
