#include "Case.h"

Case::~Case()
{

}
