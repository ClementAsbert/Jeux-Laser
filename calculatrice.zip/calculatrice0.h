#ifndef CALCULATRICE0_H
#define CALCULATRICE0_H

#include<iostream>

void calculatrice(std::istream& ist=std::cin, std::ostream& ost=std::cout);

#endif // CALCULATRICE0_H

